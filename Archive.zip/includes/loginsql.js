const db = window.openDatabase('data', '1.0', 'data', 1*1024*1024,OnSuccessCreate());
function OnSuccessCreate()
{
    console.log('Database Created.');
}
function createdatabase()
{
    //console.log('Database created.');
    db.transaction(t => {
        t.executeSql('CREATE TABLE IF NOT EXISTS login (pwd TEXT)');
        t.executeSql('CREATE TABLE IF NOT EXISTS company (code TEXT)');
        t.executeSql('Create table IF NOT EXISTS employee(id integer Primary key,fname text,lname text,father text,address text,active text default 1)');
        t.executeSql('Create table if not exists attendance(attdate text,empid integer,pstatus text,phours integer,padvance integer)');
        t.executeSql('select count(*) as count from login',[],function(tx,results)
        {
            var count=results.rows.item(0).count;
            console.log('count-> ' + count);
            if (count==0 )
            {
                t.executeSql('insert into login values(?)',['123']);
                t.executeSql('insert into company values(?)',['000']);
            }
        },null
        );
        
    }, e => console.error(e));    
}
function validatelogin(secret,callback)
{
    var sql='select count(*) as count from login where  pwd=\'' + secret +'\'';
    //console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {   
            var i= results.rows.item(0).count;
            console.log(' found password count ->' + i)    
            callback(i);
        },null);      
       
    }, e => console.error(e));
}
function readCompanyCode(callback)
{
    var sql='select code from company ';
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {   
            
            console.log('company code ->' + results.rows.item(0).code);
            callback(results.rows.item(0).code);
        },null);      
       
    }, e => console.error(e));
}
function updateCompanyCode(companyCode, callback)
{
    var sql='update Company set Code=' + companyCode;
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {   
            
            console.log('company code ->Updated done.');
            callback('Updated Sucessfully.');
        },null);      
       
    }, e => console.error(e));
}
function CreateEmployee(id,fname,lname,father,address,active, callback)
{
    var dupfound ="false";
    var createSql='insert into employee(fname,lname,father,address,active) values(?,?,?,?,?)' ;
    var updSql='update employee set fname=?,lname=?,father=?,address=?,active=? where id=?';
    var dupnameSQl ="select count(*) as count from employee where fname=? and lname=?";
    db.transaction(t => {      
        t.executeSql(dupnameSQl,[fname,lname],
        function (tx, results) {   
            var i= parseInt( results.rows.item(0).count);
            console.log('found simillar record ->' + i)    
            if (i>1)
            {
                console.log("Duplicate records.");
                dupfound="true";
                return;
            }
        },null);
    });   
    console.log("duplicate record found ");
        if (dupfound=="true")
        {
            callback("Duplicate record.....");
            return;
        }
    if (id==0)
    {
        var param=[fname,lname,father,address,active];
        var sql=createSql;
    }
    else
    {
        var param=[fname,lname,father,address,active,id];
        var sql=createSql;
    }
    console.log("duplicate record found ");
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,param,
        function (tx, results) {   
            
            console.log('Record created.-----');
            callback('Record Created/Updated Sucessfully.');
            return false;
        },null);      
       
    }, e => console.error(e));
}
function listEmpployee()
{
    var sql='select id,fname,lname,father,address from employee where active=1.0 ';
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {  
            var lielement;
           // $("#lvemployee").append("<li>first name</li>");
            console.log(results);
            var len=results.rows.length;
            console.log(i);
            var lielements ='';
            for (var i=0;i<len;i++)
            {
                lielements += '<li data-rowid='+ results.rows.item(i).id +' ><div class="ui-grid-c">' ;
                lielements += '<div class="ui-block-a"> ' + results.rows.item(i).fname +' ' + results.rows.item(i).lname +'</div>';
                lielements += '<div class="ui-block-b"> ' + results.rows.item(i).father  +'</div>';
                lielements += '<div class="ui-block-c"> ' + results.rows.item(i).address  +'</div>';
                lielements +='<div class="ui-block-d" ><div data-role="controlgroup" data-type="horizontal" ><input data-type="button" type="button" data-icon="delete" value="Delete"></div></div>';
                lielements +=' </li>';
                }
            console.log(lielements);
            $("#lvemployee").empty().append(lielements).listview('refresh');
            
            
        },null);  

       
    }, null);
}
function GenerateAttendanceScreen()
{

    var sql='select id,fname,lname,father,address from employee where active=1.0 ';
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {  
            var lielement;
           // $("#lvemployee").append("<li>first name</li>");
            console.log(results);
            var len=results.rows.length;
            console.log(i);
            var allitems='';
            for (var i=0;i<len;i++)
            {
                allitems+='<li data-rowid='+ results.rows.item(i).id +'><div class="ui-grid-a">';
                           allitems+='<div class="ui-block-a">'+results.rows.item(i).fname + ' ' + results.rows.item(i).lname +'</div>';
                           allitems+='<div class="ui-block-b"> <label  > <input type="checkbox" name="Present" id="chkpresent" />Present</label></div>';
                           allitems+='<div class="ui-block-a"><input type="text" id="txthours" value="8" placeholder="hours worked" /></div>';
                           allitems+='<div class="ui-block-b"><input type="text" value="0"  placeholder="Advance Given" id="txtadvance"/></div>';
                           allitems+='</div></li>';
             
            }
            console.log(allitems);
            $("#lvattendance").empty().append(allitems).listview('refresh');
            
            
        },null);  

       
    }, null);
}
    