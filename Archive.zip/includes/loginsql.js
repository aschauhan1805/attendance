const db = window.openDatabase('data', '1.0', 'data', 1*1024*1024,OnSuccessCreate());
function OnSuccessCreate()
{
    console.log('Database Created.');
}
function createdatabase()
{
    //console.log('Database created.');
    db.transaction(t => {
        t.executeSql('CREATE TABLE IF NOT EXISTS login (pwd TEXT)');
        t.executeSql('CREATE TABLE IF NOT EXISTS company (code TEXT)');
        t.executeSql('Create table IF NOT EXISTS employee(id integer Primary key,fname text,lname text,father text,address text,active text default 1)');
        t.executeSql('Create table if not exists attendance(attdate text,empid integer,pstatus text,phours integer,padvance integer)');
        t.executeSql('select count(*) as count from login',[],function(tx,results)
        {
            var count=results.rows.item(0).count;
            console.log('count-> ' + count);
            if (count==0 )
            {
                t.executeSql('insert into login values(?)',['123']);
                t.executeSql('insert into company values(?)',['000']);
            }
        },null
        );
        
    }, e => console.error(e));    
}
function validatelogin(secret,callback)
{
    var sql='select count(*) as count from login where  pwd=\'' + secret +'\'';
    //console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {   
            var i= results.rows.item(0).count;
            console.log(' found password count ->' + i)    
            callback(i);
        },null);      
       
    }, e => console.error(e));
}
function readCompanyCode(callback)
{
    var sql='select code from company ';
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {   
            
            console.log('company code ->' + results.rows.item(0).code);
            callback(results.rows.item(0).code);
        },null);      
       
    }, e => console.error(e));
}
function updateCompanyCode(companyCode, callback)
{
    var sql='update Company set Code=' + companyCode;
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {   
            
            console.log('company code ->Updated done.');
            callback('Updated Sucessfully.');
        },null);      
       
    }, e => console.error(e));
}
function CreateEmployee(id,fname,lname,father,address,active, callback)
{
    var dupfound ="false";
    var createSql='insert into employee(fname,lname,father,address,active) values(?,?,?,?,?)' ;
    var updSql='update employee set fname=?,lname=?,father=?,address=?,active=? where id=?';
    var dupnameSQl ="select count(*) as count from employee where fname=? and lname=?";
    db.transaction(t => {      
        t.executeSql(dupnameSQl,[fname,lname],
        function (tx, results) {   
            var i= parseInt( results.rows.item(0).count);
            console.log('found simillar record ->' + i)    
            if (i>1)
            {
                console.log("Duplicate records.");
                dupfound="true";
                return;
            }
        },null);
    });   
    console.log("duplicate record found ");
        if (dupfound=="true")
        {
            callback("Duplicate record.....");
            return;
        }
    if (id==0)
    {
        var param=[fname,lname,father,address,active];
        var sql=createSql;
    }
    else
    {
        var param=[fname,lname,father,address,active,id];
        var sql=createSql;
    }
    console.log("duplicate record found ");
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,param,
        function (tx, results) {   
            
            console.log('Record created.-----');
            callback('Record Created/Updated Sucessfully.');
            return false;
        },null);      
       
    }, e => console.error(e));
}
function listEmpployee()
{
    var sql='select id,fname,lname,father,address from employee where active=1.0 ';
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {  
            var lielement;
           // $("#lvemployee").append("<li>first name</li>");
            console.log(results);
            var len=results.rows.length;
            console.log(i);
            var lielements ='';
            for (var i=0;i<len;i++)
            {
                lielements += '<li data-rowid='+ results.rows.item(i).id +' ><div class="ui-grid-a">' ;
                lielements += '<div class="ui-block-a" style="border-right:1px solid #ccc;"> <b>Employee :</b>' + results.rows.item(i).fname +' ' + results.rows.item(i).lname +'</div>';
                lielements += '<div class="ui-block-a" > <b>Father:</b>' + results.rows.item(i).father  +'</div></div>';
                lielements += '<div class="ui-grid-a" style="padding-top:2px;"><div class="ui-block-a"> <b>Address :</b>' + results.rows.item(i).address  +'</div>';
                lielements +='<div class="ui-block-a" style="text-align:right;"><div data-role="controlgroup" data-type="horizontal" ><input data-type="button" type="button" data-icon="delete" value="Delete" id="btnedelete"><input data-type="button" type="button" data-icon="modify" value="Modify" id="btnemodify"></div></div>';
                lielements +=' </li>';
                }
            console.log(lielements);
            $("#lvemployee").empty().append(lielements).listview('refresh');
            
            
        },null);  

       
    }, null);
}

function GenerateAttendanceScreen()
{

    var sql='select id,fname,lname,father,address from employee where active=1.0 ';
    console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[],
        function (tx, results) {  
            var lielement;
           // $("#lvemployee").append("<li>first name</li>");
            console.log(results);
            var len=results.rows.length;
            console.log(i);
            var allitems='';
            for (var i=0;i<len;i++)
            {
                allitems+='<li data-rowid='+ results.rows.item(i).id +'><div class="ui-grid-a">';
                           allitems+='<div class="ui-block-a">'+results.rows.item(i).fname + ' ' + results.rows.item(i).lname +'</div>';
                           allitems+='<div class="ui-block-b"> <label  > <input type="checkbox" name="Present" id="chkpresent" />Present</label></div>';
                           allitems+='<div class="ui-block-a"><input type="number" id="txthours" value="8" placeholder="hours worked" /></div>';
                           allitems+='<div class="ui-block-b"><input type="number" value="0"  placeholder="Advance Given" id="txtadvance"/></div>';
                           allitems+='</div></li>';
             
            }
            //console.log(allitems);
            $("#lvattendance").empty().append(allitems).listview('refresh');
            
            
        },null);  
       
    }, null);
}
function saveAttendance(eid,adt,pst,phour,padvance)
{
    var createSql='insert into attendance(attdate,empid,pstatus,phours,padvance) values(?,?,?,?,?)' ;
    var updSql='update attendance set pstatus=?,phours=?,padvance=? where empid=? and attdate=?';
    var dupnameSQl ="select count(*) as count from attendance where empid=? and attdate=?";
    db.transaction(t => {      
        t.executeSql(dupnameSQl,[eid,adt],
        function (tx, results) {   
            var i= parseInt( results.rows.item(0).count);
            console.log('found simillar record ->' + i)    
            if (i>0)
            {
                var param=[pst,phour,padvance,eid,adt];
                var sql=updSql;
                db.transaction(t => {      
                    t.executeSql(sql,param,
                    function (tx, results) {   
                        
                        console.log('Record updated.');
                        console.log(sql);
                        console.log('advace' + padvance +' eid ' + eid +' chk-'+ pst+' dt '+ adt);
                        //callback('Record Created/Updated Sucessfully.');
                        //return false;
                    },null);  
                });    
            }
            else
            {
                var param=[adt,eid,pst,phour,padvance];
                var sql=createSql;
                console.log(createSql);
                db.transaction(t => {      
                    t.executeSql(sql,param,
                    function (tx, results) {    
                        console.log('Record created.-----');
                        //callback('Record Created/Updated Sucessfully.');
                        //return false;
                    },null);      
                   
                }, e => console.error(e));
            }
        
        },null);
    });
}
function readAttedance(pdate)
{
    console.log('date input  '+pdate);
    var sql='select m.id,m.fname,m.lname,s.attdate,s.pstatus,s.phours,s.padvance from employee m,attendance s where m.id=s.empid  and s.attdate=?';
    //console.log(sql)
    db.transaction(t => {      
        t.executeSql(sql,[pdate],
        function (tx, results) {   
            var allitems ='<table data-role="table" data-mode="reflow" class="ui-responsive" id="tblattendance">';
            allitems+='<thead><tr>';
            allitems+='<th data-priority="1">Employee </th>';
            allitems+='<th data-priority="persist">Date</th>';
            allitems+='<th data-priority="2">Present</th>';
            allitems+'<th data-priority="3">Hours</th>';
            allitems+='<th data-priority="4">Advance</th>';
            allitems+'</tr>';
            allitems+'</thead><tbody>';
            for(var i=0 ;i<results.rows.length; i++)
            {
                allitems+='<tr>';
                allitems+='<td>' + results.rows.item(i).fname + ' ' + results.rows.item(i).lname+'</td>';
                allitems+='<td>' + results.rows.item(i).attdate +'</td>';
                allitems+='<td>' +  (results.rows.item(i).pstatus='1' ? 'P':'A') +'</td>';
                allitems+='<td>' + results.rows.item(i).phours +'</td>';
                allitems+='<td>' + results.rows.item(i).padvance +'</td>';
                allitems+='</tr>';
            }
            allitems+='</tbody></table>';
            $("#pnlTabletoexport").empty().append(allitems);
            //console.log('company code ->' + results.rows.item(0).code);
            //callback(results.rows.item(0).code);
        },null);      
       
    }, e => console.error(e));
}

  
    

    