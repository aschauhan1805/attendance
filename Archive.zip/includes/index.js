
                $(document).on("pagecreate","#login",function(){
                    console.log('Login Called.');
                    createdatabase();
                    $("#btnlogin").on("click",function(){
                        validatelogin($('#txtpwd').val(),function(rowcount){
                         //   return rowcount;
                         console.log( 'value of rows ' + rowcount);
                         if (rowcount>0 )
                       {
                        console.log('Change page');
                           $.mobile.changePage("#dashboard");
                            //window.location.href = "dashboard.html";
                       }
                        else
                        {
                            console.log("wrong password");
                            $('#msg').fadeIn();
                            $('#msg').text('Wrong Password');
                            $('#msg').fadeOut(1000);
                        }

                        }
                        );
                        });
                });
                $(document).on('pagecreate', "#company", function(){ 
            
                    console.log('Pagecalled.');             
                    readCompanyCode(function(ccode)
                    {
                        console.log('Pagecalled.');
                        $('#ccode').val(ccode); 
                    }
                    );
                    $( "#updateCompany" ).bind( "click", function(event, ui) {
                            console.log('event called.');
                            updateCompanyCode($('#ccode').val(),function(msg)
                            {
                                $('#msg').val(msg);
                            }
                            );
                    });
                
                });
                
                $(document).on('pagecreate','#employee',  function(){ 
                    //alert('hello');
                    $("#emsg").text("");
                    console.log('Page Employee called.'); 
                    readCompanyCode(null,$('#fname').val(), $('#lname').val(),$('#father').val(),$('#address').val(),1, function(msg)
                    {
                        console.log('Page employee called.');
                        $('#ccode').val(msg); 
                    }
                    );
                    $( "#btncreateemp" ).bind( "click", function(event, ui) {
                        console.log('event called.');
                        if ($("#fname").val()=="" || $("#lname").val()=="" )
                        {
                            $("#emsg").text("Please fill First name and Last name");
                            console.log("Empty name");
                            return false;
                        }
                        console.log("call loader");
                        $.mobile.loading( 'show');
                        CreateEmployee(0,$('#fname').val(),$('#lname').val(),$('#father').val(),$('#address').val(),1,function(msg)
                        {
                            $('#emsg').text(msg);
                            cleardata();
                        });
                        //cleardata();
                        $.mobile.loading( 'hide');
                });
                function cleardata()
                {
                    $("fname").val('');
                    $("lname").val('');
                    $("father").val('');
                    $("address").val('');
    
                }
                });
                $(document).on('pagecreate','#listemployee',  function(){ 
                    listEmpployee();
                    $("#lvemployee").on("click", "li input", function(e){
                        e.stopImmediatePropagation();        
                        var rowid = $(this).parents("li").data("rowid");
                        var btnText = $(this).val();
                        alert("You clicked the button: " + btnText + " on row number: " + rowid);
                    });


                });

                $(document).on('pagecreate','#attendance',  function(){ 
                    $("#dtAttendance").val(new Date);
                    document.getElementById('dtAttendance').valueAsDate=new Date();
                    GenerateAttendanceScreen();
                    $( "#btnsaveattendance" ).bind( "click", function(event, ui) {
                        console.log($('#dtAttendance').val());
                        var listItems = $("#lvattendance li");
                            listItems.each(function(idx, li) {
                                var eid;
                                var liitem = $(li);
                                var chkstatus ;
                                var dt=$('#dtAttendance').val();
                                var thour=0;var tadvance=0;
                                        console.log(liitem.data('rowid'));
                                        eid=liitem.data('rowid');
                                        //if (liitem.find('#chkpresent').is(':checked')=='true')
                                        chkstatus=(liitem.find('#chkpresent').is(':checked') ? 1 : 0);
                                        thour=liitem.find('#txthours').val();
                                        tadvance=liitem.find('#txtadvance').val();
                                        //thour=(('#chkpresent').is(':checked') ? 1 : 0);
                                        console.log('hour'+thour);
                                        console.log('advance'+tadvance);
                                        console.log('eid' + eid);
                                        saveAttendance(eid,dt,chkstatus,thour,tadvance);
                                        GenerateAttendanceScreen();
                                        $('#h1msgatt').fadeIn();
                                        $('#h1msgatt').text('Record Saved.');
                                        $('#h1msgatt').fadeOut(300);
                                        console.log('done');
                                        //console.log(liitem.attr('chkpresent').value);
            
                                        //console.log(liitem.attr('chkpresent').value);
                            
                            });
                    });


                });
                $(document).on('pagecreate','#exportattendance',  function(){ 
                    $("#dtAtten").val(new Date);
                    document.getElementById('dtAtten').valueAsDate=new Date();
                    $("#btnShow" ).bind( "click", function(event, ui) {
                        var dt=$('#dtAtten').val();
                        console.log("date read " + dt);
                        readAttedance(dt);
                        console.log('export called ');
                        
                    });
                    $("#btnExport").bind( "click", function(event, ui) {
                        console.log("called export");
                        //exportTableToCSV();
                        //Html2CSV('tblattendance', 'myfilename','export');
                        //$("#btnExport").click(function(e) {
                            window.open('data:application/vnd.ms-excel,' + $('#pnlTabletoexport').html());
                            e.preventDefault();
                        //});
                        console.log("called export");
                    });
                      // This must be a hyperlink
                      $(".export").on('click', function(event) {
                        // CSV
                        var args = [$('#dvData>table'), 'export.csv'];
                    
                        exportTableToCSV.apply(this, args);
                    
                        // If CSV, don't do event.preventDefault() or return false
                        // We actually need this to be a typical hyperlink
                      });
                    
                });
                
                